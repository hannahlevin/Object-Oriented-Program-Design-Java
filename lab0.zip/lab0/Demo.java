// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// Demo.java
// First Java program
// Lab 0
// 6-13-2018

public class Demo {

	public static void main( String[] args ) {

		System.out.println("Here is a Java program");		
		System.out.println("Written by Hannah Levin");

	}
}
