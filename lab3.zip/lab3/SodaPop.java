// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// SodaPop.java
// Printing numbers 1-100 and substituting numbers divisible by 3, 5, or both with "Soda", "Pop", and "*SP*" respectively
// Lab 3
// 7-2-2018
// I have not cheated or plagiarized on this lab.

public class SodaPop {
	public static void main(String[] args) {

		// Declare and initialize int number
		int number = 1;

		// While loop to iterate numbers 1-100
		while (number <= 100) {

			// Number is divisable by 3 and by 5, print "*SP*"
			if (number % 3 == 0) {
				if (number % 5 == 0) {
					System.out.printf("%5s", "*SP*");
				}
				// Number is divisable by only 3, and not 5, print "Soda"
				else {
					System.out.printf("%5s", "Soda");
				}
			}

			// Number is divisable by only 5, print "Pop"
			else if (number % 5 == 0) {
				System.out.printf("%5s", "Pop");
			}

			// Number is not divisable by neither 3 or 5, print the actual number
			else {
				System.out.printf("%5d", number);

			}

			// Print a new line after every 10 outputs
			if (number % 10 == 0) {
				System.out.println();
			}

			// Increment number by 1
			number++;
		}

		// Print my name
		System.out.printf("%nProgrammed by Hannah Levin%n");
	}
}