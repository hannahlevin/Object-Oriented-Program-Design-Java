// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// BicycleTest.java
// Bicycle print owner name and license number Java program
// Lab 2
// 6-25-2018
// I have not cheated or plagiarized on this assignment.


public class BicycleTest {

    public static void main( String[] args )  {

    	// print line that says my name
    	System.out.println("Programmed by Hannah Levin");

		// Declare 1 Bicycle reference variable - do NOT initialize
		Bicycle bike;


		// Declare 1 String reference variable for the owner's name
		// Do NOT initialize
		String ownerName;


		// Declare 1 integer variable for license number
		// Do NOT initialize
		int licenseNumber;


		// Assign your full name and a license number to the String and
		// integer variables (initialize the variables)
		ownerName = "Hannah Levin";
		licenseNumber = 158392;


		// Assign a Bicycle object to the Bicycle reference variable
		// Use the Bicycle class constructor to create the object
		// Use the variables you created as arguments to the constructor
		bike = new Bicycle (ownerName, licenseNumber);


	    // Output the owner's name and license number in printf statements
		// using the Bicycle reference variable and the get methods.
		// For example: bike.getOwnerName()
		System.out.printf("%s%s%n%s%d%n", "Owner of bike: ", bike.getOwnerName(), "License number: ", bike.getLicenseNumber());


		// Change the owner's name to Homer Simpson using setOwnerName
		bike.setOwnerName("Homer Simpson");



		// Output the owner's name and license number again in printf statements
		// using the Bicycle reference variable and the get methods.
		System.out.printf("%s%s%n%s%d%n", "Owner of bike: ", bike.getOwnerName(), "License number: ", bike.getLicenseNumber());


    }
}