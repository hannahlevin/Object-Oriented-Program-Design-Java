// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// AccountTest.java
// Account inputting and outputting balance, withdrawal, and deposit Java program
// Assignment 2
// 6-26-2018
// I have not cheated or plagiarized on this assignment.

import java.util.Scanner;

public class AccountTest {
   public static void main(String[] args) {
      System.out.println("Programmed by Hannah Levin"); // print a line that has my name 

      Account account1 = new Account("Oprah Winfrey", 600.00);
      Account account2 = new Account("Albert Einstein", 900.00); 

      // display initial balance of each object
      System.out.printf("%n%s balance: $%.2f%n",
         account1.getName(), account1.getBalance()); 
      System.out.printf("%s balance: $%.2f%n%n",
         account2.getName(), account2.getBalance()); 

      // create a Scanner to obtain input from the command window
      Scanner input = new Scanner(System.in);

      System.out.print("Enter withdrawal amount for account1: "); // prompt withdrawal amount
      double withdrawalAmount = input.nextDouble(); // obtain user input
      System.out.printf("%nsubtracting %.2f from account1 balance%n%n", 
         withdrawalAmount);
      account1.withdraw(withdrawalAmount); // subtract from account1's balance

      // display balance of account1
      System.out.printf("%s balance: $%.2f%n",
         account1.getName(), account1.getBalance());

      System.out.printf("%nEnter withdrawal amount for account2: "); // prompt withdrawal amount
      withdrawalAmount = input.nextDouble(); // obtain user input
      System.out.printf("%nsubtracting %.2f from account2 balance%n%n", 
         withdrawalAmount);
      account2.withdraw(withdrawalAmount); // subtract from account2 balance

      // display balance of account2
      System.out.printf("%s balance: $%.2f%n%n",
         account2.getName(), account2.getBalance()); 

      System.out.println("The computer is now adding $400.00 to account1 balance"); // printing an explanation of the next operation
      account1.deposit(400.00); // add $400.00 to account1's balance

      // display balance of account1
      System.out.printf("%s balance: $%.2f%n",
         account1.getName(), account1.getBalance());

      System.out.printf("%nThe computer is now adding $350.00 to account2 balance%n"); // printing an explanation of the next operation
      account2.deposit(350.00); // add $350.00 to account2 balance

      // display balance of account2
      System.out.printf("%s balance: $%.2f%n%n",
         account2.getName(), account2.getBalance()); 
   } 
}