// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// MyInfo.java
// Second Java program
// Lab 1
// 6-16-2018

public class MyInfo {

	public static void main( String[] args ) {

		System.out.println("Name: Hannah Levin");		
		System.out.println("Major: Computer Science");

	}
}
