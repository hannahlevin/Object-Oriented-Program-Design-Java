// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// Shapes.java
// Printing shapes Java program
// Assignment 1
// 6-20-2018
// I have not cheated or plagiarized on this assignment.

public class Shapes { // begin class Shapes

	// main method begins the execution of the Java application
	public static void main(String[] args) {

		System.out.println("Programmed by Hannah Levin"); // printing my name

		// print shapes line by line
		System.out.println("*********      ***        *          * "); // printing the 1st line of the shapes
        System.out.println("*       *    *     *     ***        * * "); // printing the 2nd line of the shapes
        System.out.println("*       *   *       *   *****      *   * "); // printing the 3rd line of the shapes
        System.out.println("*       *   *       *     *       *     * "); // printing the 4th line of the shapes
        System.out.println("*       *   *       *     *      *       * "); // printing the 5th line of the shapes
        System.out.println("*       *   *       *     *       *     * "); // printing the 6th line of the shapes
        System.out.println("*       *   *       *     *        *   * "); // printing the 7th line of the shapes
        System.out.println("*       *    *     *      *         * * "); // printing the 8th line of the shapes
        System.out.println("*********      ***        *          * "); // printing the 9th line of the shapes
    } // end method main
} // end class Shapes