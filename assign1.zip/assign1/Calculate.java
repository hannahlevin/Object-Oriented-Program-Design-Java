// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// Calculate.java
// Calculating and comparing Java program
// Assignment 1
// 6-19-2018
// I have not cheated or plagiarized on this assignment.

import java.util.Scanner; // program uses class Scanner

public class Calculate { 

	// main method begins execution of Java application
	public static void main(String[] args) {

		System.out.println("Programmed by Hannah Levin");

		// create a Scanner to obtain input from the command window
		Scanner input = new Scanner(System.in);

		System.out.print("Enter first integer: "); // prompt
		int number1 = input.nextInt(); // read first number from user

		System.out.print("Enter second integer: "); // prompt
		int number2 = input.nextInt(); // read second number from user

		int sum = number1 + number2; // add numbers, then store total in sum

		int difference = number1 - number2; // subtract numbers, then store total in difference

		int product = number1 * number2; // multiply numbers, then store total in product

		int quotient = number1 / number2; // divide numbers, then store total in quotient

		int remainder = number1 % number2; // use the remainder operator, then store the remainder in remainder

		System.out.printf("Sum is %d%n", sum); // display sum

		System.out.printf("Difference is %d%n", difference); // display difference

		System.out.printf("Product is %d%n", product); // display product

		System.out.printf("Quotient is %d%n", quotient); // display quotient

		System.out.printf("Remainder is %d%n", remainder); // display remainder

		if(number1 > number2) {
			System.out.println(number1 + " is greater than " + number2);
		}

		else if(number1 < number2) {

			System.out.println(number1 + " is less than " + number2);

		}

		else {

			System.out.println(number1 + " is equal to " + number2);

		}

	} // end method main
} // end class Calculate