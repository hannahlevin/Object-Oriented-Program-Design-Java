// Hannah Levin
// I have not cheated or plagiarized on question 1

public class FitnessTrackerTest {
	public static void main(String[] args) {

		FitnessTracker tracker1 = new FitnessTracker ("Fitbit Charge 2", "Windows, Android, iOS", 145.20);
		FitnessTracker tracker2 = new FitnessTracker ("Garmin Vivosport", "Android, iOS", 169.99);
		FitnessTracker tracker3 = new FitnessTracker ("Fitbit Versa", "Windows, Android, iOS", 199.95);
		FitnessTracker tracker4 = new FitnessTracker ("Garmin Forerunner 35", "Windows, Android, iOS", 187.10);

		FitnessTracker [] trackers = {tracker1, tracker2, tracker3, tracker4};


		System.out.println("Fitness Trackers");
		System.out.println(tracker1.toString());
		System.out.println(tracker2.toString());
		System.out.println(tracker3.toString());
		System.out.println(tracker4.toString());

	}
}