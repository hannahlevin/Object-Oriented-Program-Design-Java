// Hannah Levin
// I have not cheated or plagiarized on question 1

public class FitnessTracker {

	private String product;
	private String compatibility;
	private double price = 0.0;

	public FitnessTracker (String product, String compatibility, double price) {
		this.product = product;
		this.compatibility = compatibility;

		if (price >= 0.0) {
		this.price = price;
		}
	}

	public void setProduct (String product) {
		this.product = product;
	}

	public void setCompatibility (String compatibility) {
		this.compatibility = compatibility;
	}
	
	public void setPrice (double price) {

		if (price >= 0.0) {
			this.price = price;
		}
	}

	public String getProduct () {
		return product;
	}

	public String getCompatibility () {
		return compatibility;
	}

	public double getPrice () {
		return price;
	}

	public String toString () {
		return String.format("%s Compatibility: %s Price: $%.2f%n", product, compatibility, price);
	}
}