// Hannah Levin
// hannahlevin@my.smccd.edu
// CIS 254 ON
// FindLargeSmall.java
// Compare entered numbers by user and determine the largest and the smallest numbers entered Java program
// Assignment 3
// 7-4-2018
// I have not cheated or plagiarized on this assignment.

import java.util.Scanner; // class uses class Scanner

public class FindLargeSmall {
	public static void main(String[] args) {
		// create Scanner to obtain input from command window
		Scanner input = new Scanner(System.in);
		
		// prompt for input and read number from user
		System.out.print("Enter an integer: ");
		int smallestNumber = input.nextInt(); // assign the first number entered as smallestNumber
		int greatestNumber = smallestNumber; // assign the first number entered, greatestNumber, as smallestNumber
		int counterNumber = 1; // initialize # of numbers entered so far

		// process 10 inputted numbers using counter-controlled loop
		while (counterNumber < 10) {
			// prompt user for input and obtain value from user
			System.out.print("Enter an integer: ");
			int number = input.nextInt();

			// if is nested in the while statement
			if (number < smallestNumber) {
				smallestNumber = number; // if the number entered is smaller than the existing smallestNumber, assign number to smallestNumber	
			}
			// if is nested in the while statement
			if (number > greatestNumber) {
				greatestNumber = number; // if the number entered is bigger than the existing greatestNumber, assign number to greatestNumber 
			}
			// increment counterNumber by one
			counterNumber++;
		}
		// display the greatest number and the smallest number in the output
		System.out.printf("%nThe greatest number is: %d%n", greatestNumber);
		System.out.println("The smallest number is: " + smallestNumber);

		// display my name in the output
		System.out.printf("%nProgrammed by Hannah Levin%n%n");
	}
}